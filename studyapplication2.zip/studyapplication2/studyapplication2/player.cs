﻿using System;
using System.Collections.Generic;
using System.Text;

namespace studyapplication2
{
    class player
    {
        public string Name;
        public int Score;
        public player(string name, int score)
        {
            Name = name;
            Score=0;
            
        }
    }
}
