﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.IO;


namespace studyapplication2
{
    class game
    {
        public string Name;
        
        
    }
}
