﻿using System;
using System.IO;
// Lacie 2021 3.8//
//Karen Spriggs and Austin Derrickson helped me with writing the random&loop and external file accessing//
namespace studyapplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            exercise Exercise = new exercise();
            bool wantsToPlay = true;
            while (wantsToPlay)
            {
                Console.WriteLine("What would you like to do?");
                Console.WriteLine("\n\n1) start quiz\n2) Add question\n3) Quit game");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1 : 
                        Exercise.showexercise();
                        break;
                    case 2 :
                        Exercise.newquestion();
                        break;
                    case 3 :
                        wantsToPlay = false;
                        break;
                    default:
                        Console.WriteLine("Invalid input, please input a value great than 0");
                        break;
                }
            }
        }
    }
}
