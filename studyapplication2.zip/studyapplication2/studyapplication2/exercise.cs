﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using static System.Console;
using System.Linq;

namespace studyapplication2
{
    class exercise
    {
        public string Name;
        List<string> questions;
        List<string> answers;
        List<string> correctanswer;
        List<int> tracking= new List<int>();
        player Player1 = new player("Player1", 0);
        System.Random rand = new System.Random();

        public void InitializeQuiz()
        {
            questions = File.ReadAllLines(@"C:\Users\玥\Desktop\编程\studyapplication2\studyapplication2\questions.txt").ToList<string>();
            answers = File.ReadAllLines(@"C:\Users\玥\Desktop\编程\studyapplication2\studyapplication2\answers.txt").ToList<string>();
            correctanswer = File.ReadAllLines(@"C:\Users\玥\Desktop\编程\studyapplication2\studyapplication2\correctanswer.txt").ToList<string>();
        }
        public void showexercise()
        {
            InitializeQuiz();
            for (int q = 0; q < questions.Count; q++)
            {
                int sequence = randomlize();
                Console.WriteLine($"{questions[sequence]}");
               
                foreach (var a in answers[sequence])
                {
                    Console.WriteLine(a);
                }
              
                checkanswer(sequence);
               
                stopthegame();
               
            }

            newquestion();

        }
        
        public void newquestion()
        {
            InitializeQuiz();
            Console.WriteLine();
            Console.WriteLine("What is your question?");
            string question = Console.ReadLine();
            if(question!=null)
            {
                string allQuestions = "";
                questions.Add(question);
                foreach (var OldQuestion in questions)
                {
                    allQuestions += $"{OldQuestion}\n";
                }
                File.WriteAllText(@"C:\Users\玥\Desktop\编程\studyapplication2\studyapplication2\questions.txt", allQuestions);
            }

            Console.WriteLine("What are those choices?");
            string choice = Console.ReadLine();
            if(choice!=null)
            {
                answers.Add(choice);
            }
            Console.WriteLine("What is the correct answer?");
            string corrextanswer = Console.ReadLine();
            if(correctanswer!=null)
            {
                correctanswer.Add(corrextanswer);
            } 
           
        }
        public void checkanswer(int sequence)
        {
            Console.WriteLine("T Means true, F means Flase. What is your answer?");
            string input = Console.ReadLine();
            input = input.ToUpper();
            bool valid_input = true;
            while (valid_input)
            {
                if (input == correctanswer[sequence])
                {
                    Console.WriteLine("That is correct");
                    Player1.Score++;

                }
                
                else if(input!=correctanswer[sequence]&&(input=="T"||input=="F"))
                {
                    Console.WriteLine("Sorry that is incorrect");
                }
                else
                {
                    Console.WriteLine("Invalid input");
                    valid_input = false;
                   
                }
                Console.WriteLine($"Your score is {Player1.Score}");
                Console.ReadKey();
                Console.Clear();
                break;
            }
        }

       

        public int randomlize()
        {
            int Index = rand.Next(0, questions.Count);
            if(tracking.Contains(Index))
            {
                randomlize();
            }
            else
            {
                tracking.Add(Index);
                return (Index);
            }



            return (Index);
        }

        public void stopthegame()
        {
            Console.WriteLine("Press N to stop the game");
            string playerinput = Console.ReadLine();
            playerinput = playerinput.ToUpper();

            if (playerinput == "N")
            {
                Console.WriteLine($"Your score is {Player1.Score}");
                Environment.Exit(0);
            }

            else
            {
                return;

            }





        }

        
    }
}
